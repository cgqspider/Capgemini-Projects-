# chungTimePicker
一款基于jQuery的时间点选择插件

>界面样式风格参考bootstrap时间选择控件

>欢迎各位通过email发现bug和指点意见
